<?php

$username = $_GET["username"];

$query = "SELECT * FROM users WHERE username = '$username'";

$result = mysqli_query($connection, $query);

print_r(mysqli_fetch_all($result));
?>