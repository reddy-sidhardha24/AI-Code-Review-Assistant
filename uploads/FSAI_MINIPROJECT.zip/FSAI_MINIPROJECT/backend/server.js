// ============================================
// TypeBlitz — Backend Server
// ============================================
// A simple Express server with MongoDB for the
// TypeBlitz typing speed game.
//
// API Routes:
//   POST /signup        — Create a new player (unique username)
//   POST /login         — Verify existing player
//   GET  /players       — Get all players (leaderboard)
//   POST /update-range  — Update player's typing range
//   GET  /generate-practice — Get a practice pattern
//   GET  /generate-test — Get a random typing test text
// ============================================

// --- 1. Load environment variables from .env file ---
const dotenv = require("dotenv");
dotenv.config();

// --- 2. Import required packages ---
const express = require("express");   // web framework
const mongoose = require("mongoose"); // MongoDB helper
const cors = require("cors");         // allows frontend to talk to backend

// --- 3. Create the Express app ---
const app = express();
app.use(cors());           // allow cross-origin requests
app.use(express.json());   // parse JSON request bodies

// --- 4. Read config from .env ---
const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/typeblitz";
const PORT = process.env.PORT || 5000;

// --- 5. Connect to MongoDB ---
mongoose
  .connect(MONGO_URI)
  .then(() => console.log("✅ Connected to MongoDB"))
  .catch((err) => console.error("❌ MongoDB connection error:", err));

// ============================================
// DATABASE SCHEMA
// ============================================
// Each player has a username and a typing speed range (0-100%)
// Collection name: "players"

const playerSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,   // username is mandatory
    unique: true,     // no two players can have the same name
  },
  typingRange: {
    type: Number,
    default: 0,       // new players start at 0%
  },
});

// Create the Player model from the schema
// Mongoose will use the "players" collection in MongoDB
const Player = mongoose.model("Player", playerSchema);

// ============================================
// PREDEFINED TEST TEXTS (AI Text Generator)
// ============================================
// These sentences are used for the typing test.
// We use predefined text instead of an external AI API
// to keep the project simple and beginner-friendly.

const testTexts = [
  "Artificial intelligence improves productivity.",
  "The quick brown fox jumps over the lazy dog.",
  "Learning to code opens many doors for your future.",
  "Practice makes perfect when it comes to typing speed.",
  "JavaScript is one of the most popular programming languages.",
  "Cloud computing allows businesses to scale easily.",
  "Data science helps companies make better decisions.",
  "Good developers write code that humans can understand.",
  "The internet connects billions of people around the world.",
  "Machine learning algorithms improve with more data.",
  "React is a library for building user interfaces.",
  "MongoDB stores data in flexible JSON like documents.",
  "Every expert was once a beginner who never gave up.",
  "Technology is best when it brings people together.",
  "Typing fast and accurately is a valuable skill today.",
];

// ============================================
// API ROUTE 1: POST /signup
// ============================================
// PURPOSE: Create a new player account.
// LOGIC:
//   1. Get the username from the request body.
//   2. Check if username already exists in MongoDB.
//   3. If it exists → return error message.
//   4. If it's new → create the player with typingRange = 0.

app.post("/signup", async (req, res) => {
  try {
    // Get the username from the request body
    const { username } = req.body;

    // Check if username was provided
    if (!username || username.trim() === "") {
      return res.status(400).json({ error: "Username is required." });
    }

    // --- MongoDB Query: Check if username already exists ---
    const existingPlayer = await Player.findOne({ username: username.trim() });

    if (existingPlayer) {
      // Username is taken — send error message
      return res
        .status(400)
        .json({ error: "Username already exists. Please choose another name." });
    }

    // --- MongoDB Query: Create a new player document ---
    const newPlayer = new Player({
      username: username.trim(),
      typingRange: 0,  // default typingRange = 0%
    });

    // Save the new player to the "players" collection
    await newPlayer.save();

    // Send back success response
    res.json({
      message: "Player created successfully!",
      player: newPlayer,
    });
  } catch (error) {
    console.error("Signup error:", error);
    res.status(500).json({ error: "Server error during signup." });
  }
});

// ============================================
// API ROUTE 2: POST /login
// ============================================
// PURPOSE: Verify that a player exists in the database.
// LOGIC:
//   1. Get the username from the request body.
//   2. Search for it in MongoDB.
//   3. If found → return player data (login success).
//   4. If not found → return error message.

app.post("/login", async (req, res) => {
  try {
    // Get the username from the request body
    const { username } = req.body;

    // Check if username was provided
    if (!username || username.trim() === "") {
      return res.status(400).json({ error: "Username is required." });
    }

    // --- MongoDB Query: Find the player by username ---
    const player = await Player.findOne({ username: username.trim() });

    if (!player) {
      // Player not found — they need to sign up first
      return res
        .status(404)
        .json({ error: "Player not found. Please sign up first." });
    }

    // Player found — login successful
    res.json({
      message: "Login successful!",
      player: player,
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Server error during login." });
  }
});

// ============================================
// API ROUTE 2: GET /players
// ============================================
// Returns a list of all players sorted by typing range (highest first).

app.get("/players", async (req, res) => {
  try {
    // Find all players and sort by typingRange in descending order
    const allPlayers = await Player.find().sort({ typingRange: -1 });

    // Send the list back as JSON
    res.json(allPlayers);
  } catch (error) {
    console.error("Fetch players error:", error);
    res.status(500).json({ error: "Failed to fetch players." });
  }
});

// ============================================
// API ROUTE 3: POST /update-range
// ============================================
// Updates a player's typing speed range after a test.
// Expects: { username: "Mary", typingRange: 65 }

app.post("/update-range", async (req, res) => {
  try {
    // Get username and new typing range from request body
    const { username, typingRange } = req.body;

    // Find the player by username and update their typing range
    const updatedPlayer = await Player.findOneAndUpdate(
      { username: username },           // find this player
      { typingRange: typingRange },      // set new typing range
      { new: true }                      // return the updated document
    );

    // If player not found
    if (!updatedPlayer) {
      return res.status(404).json({ error: "Player not found." });
    }

    // Send back the updated player
    res.json({
      message: "Typing range updated!",
      player: updatedPlayer,
    });
  } catch (error) {
    console.error("Update range error:", error);
    res.status(500).json({ error: "Failed to update typing range." });
  }
});

// ============================================
// AI PATTERN GENERATOR — Helper Functions
// ============================================
// These functions act as our "AI model" to generate
// different typing patterns for 3 practice levels:
//   Level 1: Alphabet patterns (keyboard rows)
//   Level 2: Number patterns
//   Level 3: Simple words

// --- Keyboard rows (used to create alphabet patterns) ---
const homeRow = ["a", "s", "d", "f", "g", "h", "j", "k", "l", ";"];
const topRow = ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"];
const bottomRow = ["z", "x", "c", "v", "b", "n", "m"];

// --- Number keys (used to create number patterns) ---
const numbers = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];

// Helper: shuffle an array randomly
function shuffle(array) {
  const arr = [...array]; // make a copy
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]]; // swap
  }
  return arr;
}

// Helper: pick N random items from an array
function pickRandom(array, count) {
  const shuffled = shuffle(array);
  return shuffled.slice(0, count);
}

// --- AI Pattern Generator for each level ---
function generatePattern(level) {
  if (level === 1) {
    // Level 1: Alphabet patterns — pick a random keyboard row
    const rows = [homeRow, topRow, bottomRow];
    const chosenRow = rows[Math.floor(Math.random() * rows.length)];
    const group1 = pickRandom(chosenRow, 4).join("");
    const group2 = pickRandom(chosenRow, 4).join("");
    return group1 + " " + group2;
  }

  if (level === 2) {
    // Level 2: Number patterns
    const group1 = pickRandom(numbers, 5).join("");
    const group2 = pickRandom(numbers, 5).join("");
    return group1 + " " + group2;
  }

  // Level 3: Simple words
  const simpleWords = [
    "cat", "dog", "pen", "hat", "box", "run", "fly", "sit",
    "cup", "map", "sun", "fox", "jam", "web", "zip", "van",
    "owl", "key", "big", "mix", "joy", "quiz", "gum", "hut",
  ];
  const words = pickRandom(simpleWords, 4);
  return words.join(" ");
}

// ============================================
// API ROUTE 4: GET /generate-practice
// ============================================
// AI generates a random typing pattern for the given level.
// Query param: level (1-3)
// Returns: { pattern: "asdf ghjk", level: 1, levelName: "Alphabet Patterns" }

app.get("/generate-practice", (req, res) => {
  // Read the level from query (default = 1)
  let level = parseInt(req.query.level) || 1;

  // Clamp level between 1 and 3
  level = Math.max(1, Math.min(3, level));

  // Level names for display
  const levelNames = {
    1: "Alphabet Patterns",
    2: "Number Patterns",
    3: "Simple Words",
  };

  // Generate a random pattern using our AI generator
  const pattern = generatePattern(level);

  // Send back the pattern
  res.json({
    pattern: pattern,
    level: level,
    levelName: levelNames[level],
  });
});

// ============================================
// API ROUTE 5: GET /generate-test
// ============================================
// Returns a random sentence for the typing test.
// This acts as our simple "AI text generator".

app.get("/generate-test", (req, res) => {
  // Pick a random index from the testTexts array
  const randomIndex = Math.floor(Math.random() * testTexts.length);

  // Get the random sentence
  const text = testTexts[randomIndex];

  // Send it back
  res.json({ text: text });
});

// ============================================
// START THE SERVER
// ============================================
app.listen(PORT, () => {
  console.log(`🚀 TypeBlitz server running on http://localhost:${PORT}`);
});
