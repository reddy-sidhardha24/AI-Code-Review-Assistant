// ============================================
// App.jsx — Main app with routing
// ============================================
// This file sets up all the routes (pages) for the game.
//
// APPLICATION FLOW:
//   Home Page (/) → User clicks Sign Up or Login
//     ↓ Sign Up (/signup) → Enter new username → Backend checks DB
//       → If unique → create player → Redirect to Login
//     ↓ Login (/login) → Enter username → Backend checks DB
//       → If exists → open Dashboard
//       → If not exists → show error, suggest Sign Up
//     ↓ Dashboard (/dashboard) → Practice or Test
//
// Routes:
//   /           → Home page (game title + Sign Up & Login buttons)
//   /signup     → Sign Up page (create new account)
//   /login      → Login page (verify existing player)
//   /dashboard  → Player dashboard (leaderboard + buttons)
//   /practice   → Practice mode (typing patterns)
//   /test       → Test mode (typing speed test)
//   /result     → Result page (show typing range)
// ============================================

import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import SignupPage from "./pages/SignupPage";   // NEW: Sign Up page
import LoginPage from "./pages/LoginPage";
import Dashboard from "./pages/Dashboard";
import PracticePage from "./pages/PracticePage";
import TestPage from "./pages/TestPage";
import ResultPage from "./pages/ResultPage";

// --- Main App Component ---
function App() {
  return (
    // BrowserRouter enables page navigation without page reload
    <BrowserRouter>
      <Routes>
        {/* Home page — shows game title, Sign Up and Login buttons */}
        <Route path="/" element={<HomePage />} />

        {/* Sign Up page — new player creates an account */}
        <Route path="/signup" element={<SignupPage />} />

        {/* Login page — existing player enters username to login */}
        <Route path="/login" element={<LoginPage />} />

        {/* Dashboard — shows leaderboard and practice/test buttons */}
        <Route path="/dashboard" element={<Dashboard />} />

        {/* Practice mode — typing practice with patterns */}
        <Route path="/practice" element={<PracticePage />} />

        {/* Test mode — timed typing test */}
        <Route path="/test" element={<TestPage />} />

        {/* Result page — shows typing range after test */}
        <Route path="/result" element={<ResultPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
