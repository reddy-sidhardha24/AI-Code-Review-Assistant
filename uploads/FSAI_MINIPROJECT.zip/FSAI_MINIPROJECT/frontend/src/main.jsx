// ============================================
// main.jsx — Entry point of the React app
// ============================================
// This file renders the App component into the HTML page.
// ============================================

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css"; // import global styles

// Find the root div in index.html and render our app there
ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
