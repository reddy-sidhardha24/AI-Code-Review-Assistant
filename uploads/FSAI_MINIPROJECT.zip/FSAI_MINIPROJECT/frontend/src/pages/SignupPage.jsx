// ============================================
// SignupPage.jsx — Sign Up Page
// ============================================
// PURPOSE: Allow a new player to create an account.
//
// SIGNUP LOGIC:
//   1. Player enters a username in the input field.
//   2. When they click "Sign Up", we send the username
//      to the backend via POST /signup.
//   3. Backend checks MongoDB:
//      - If username already exists → show error.
//      - If username is new → create player, redirect to Login.
// ============================================

import { useState } from "react";
import { useNavigate } from "react-router-dom";

// Backend URL (Express server)
const API_URL = "http://localhost:5001";

function SignupPage() {
  // State to store the username typed by the player
  const [username, setUsername] = useState("");

  // State to store any error message (e.g., "Username already exists")
  const [error, setError] = useState("");

  // State to store success message after signup
  const [success, setSuccess] = useState("");

  // State to show loading while waiting for server response
  const [loading, setLoading] = useState(false);

  // useNavigate lets us go to another page programmatically
  const navigate = useNavigate();

  // --- Handle Sign Up button click ---
  const handleSignup = async () => {
    // Clear any previous error or success messages
    setError("");
    setSuccess("");

    // Check if username is empty
    if (username.trim() === "") {
      setError("Please enter a username.");
      return;
    }

    // Show loading spinner
    setLoading(true);

    try {
      // Send POST request to /signup on the backend
      // This sends the username as JSON in the request body
      const response = await fetch(API_URL + "/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: username.trim() }),
      });

      // Parse the JSON response from the server
      const data = await response.json();

      if (!response.ok) {
        // Server returned an error (e.g., username already taken)
        setError(data.error);
        setLoading(false);
        return;
      }

      // Signup successful — show success message
      setSuccess("Account created! Redirecting to Login...");
      setLoading(false);

      // Wait 1.5 seconds, then redirect to the Login page
      setTimeout(() => {
        navigate("/login");
      }, 1500);
    } catch (err) {
      // Network error or server not running
      setError("Cannot connect to server. Make sure the backend is running.");
      setLoading(false);
    }
  };

  // --- Handle Enter key press (submit form on Enter) ---
  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleSignup();
    }
  };

  return (
    <div className="page-container signup-page">
      {/* Page title */}
      <h2 className="page-title">Sign Up</h2>

      {/* Card container */}
      <div className="card">
        {/* Username input field */}
        <label className="input-label">Choose a username:</label>
        <input
          type="text"
          className="text-input"
          placeholder="e.g. Mary"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          onKeyDown={handleKeyPress}
        />

        {/* Show error message if any */}
        {error && <p className="error-message">{error}</p>}

        {/* Show success message if signup worked */}
        {success && <p className="success-message">{success}</p>}

        {/* Sign Up button */}
        <button
          className="btn btn-primary"
          onClick={handleSignup}
          disabled={loading}
        >
          {loading ? "Creating account..." : "Sign Up"}
        </button>
      </div>

      {/* Link to go to Login page if already have an account */}
      <button className="btn btn-link" onClick={() => navigate("/login")}>
        Already have an account? Login
      </button>

      {/* Back to home link */}
      <button className="btn btn-link" onClick={() => navigate("/")}>
        ← Back to Home
      </button>
    </div>
  );
}

export default SignupPage;
