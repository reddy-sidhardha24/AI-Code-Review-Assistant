// ============================================
// HomePage.jsx — Home Screen
// ============================================
// This is the first page the player sees.
// It shows the game title "TYPEBLITZ" and two buttons:
//   1. Sign Up — for new players to create an account
//   2. Login  — for existing players to enter the game
// ============================================

import { useNavigate } from "react-router-dom";

function HomePage() {
  // useNavigate lets us go to another page when button is clicked
  const navigate = useNavigate();

  return (
    <div className="page-container home-page">
      {/* Game title */}
      <h1 className="game-title">⌨️ TYPEBLITZ</h1>

      {/* Game subtitle */}
      <p className="game-subtitle">AI Typing Speed Game</p>

      {/* Button group — Sign Up and Login */}
      <div className="button-group">
        {/* Sign Up button — navigates to the signup page */}
        <button className="btn btn-primary" onClick={() => navigate("/signup")}>
          Sign Up
        </button>

        {/* Login button — navigates to the login page */}
        <button className="btn btn-success" onClick={() => navigate("/login")}>
          Login
        </button>
      </div>
    </div>
  );
}

export default HomePage;
