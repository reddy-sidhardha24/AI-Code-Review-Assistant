// ============================================
// ResultPage.jsx — Result Screen
// ============================================
// Shows the player's typing range after completing a test.
// Has buttons to practice again or go to dashboard.
// ============================================

import { useNavigate, useLocation } from "react-router-dom";

function ResultPage() {
  // useLocation gives us the data passed from the TestPage
  const location = useLocation();

  // useNavigate lets us go to another page
  const navigate = useNavigate();

  // Get the result data from navigation state
  // If no data (page was refreshed), use default values
  const typingRange = location.state?.typingRange || 0;
  const wpm = location.state?.wpm || 0;
  const accuracy = location.state?.accuracy || 0;   // accuracy %
  const timeTaken = location.state?.timeTaken || 0;

  // --- Determine performance message based on range ---
  let performanceMessage = "";
  if (typingRange >= 90) {
    performanceMessage = "🏆 Expert! You are a typing master!";
  } else if (typingRange >= 70) {
    performanceMessage = "🌟 Great! You type very fast!";
  } else if (typingRange >= 40) {
    performanceMessage = "👍 Good! Keep practicing to improve!";
  } else if (typingRange >= 10) {
    performanceMessage = "💪 Average. Practice will help you improve!";
  } else {
    performanceMessage = "🔰 Beginner. Try practicing more!";
  }

  return (
    <div className="page-container result-page">
      {/* Page title */}
      <h2 className="page-title">📊 Test Result</h2>

      {/* Result card */}
      <div className="card result-card">
        {/* Main typing range display */}
        <div className="range-display">
          <p className="range-label">Your Typing Range:</p>
          <p className="range-value">{typingRange}%</p>
        </div>

        {/* Progress bar showing the range visually */}
        <div className="progress-bar-container">
          <div
            className="progress-bar-fill"
            style={{ width: `${typingRange}%` }}
          ></div>
        </div>

        {/* Performance message */}
        <p className="performance-message">{performanceMessage}</p>

        {/* Additional stats — speed, accuracy, time */}
        <div className="stats-row">
          <div className="stat-box">
            <p className="stat-label">Speed</p>
            <p className="stat-value">{wpm} WPM</p>
          </div>
          <div className="stat-box">
            <p className="stat-label">Accuracy</p>
            <p className="stat-value">{accuracy}%</p>
          </div>
          <div className="stat-box">
            <p className="stat-label">Time Taken</p>
            <p className="stat-value">{timeTaken}s</p>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="button-group">
        <button className="btn btn-primary" onClick={() => navigate("/practice")}>
          📝 Practice Again
        </button>
        <button className="btn btn-secondary" onClick={() => navigate("/dashboard")}>
          Go to Dashboard
        </button>
      </div>
    </div>
  );
}

export default ResultPage;
