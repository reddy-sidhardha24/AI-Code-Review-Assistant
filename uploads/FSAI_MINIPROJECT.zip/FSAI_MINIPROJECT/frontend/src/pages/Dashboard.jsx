// ============================================
// Dashboard.jsx — Player Dashboard
// ============================================
// Shows a list of all players with their typing ranges.
// The currently logged-in player is always at the TOP.
// Has buttons to go to Practice or Test mode.
// ============================================

import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

// Backend URL
const API_URL = "http://localhost:5001";

function Dashboard() {
  // State to store the list of players
  const [players, setPlayers] = useState([]);

  // State to show if data is loading
  const [loading, setLoading] = useState(true);

  // Get the logged-in username from localStorage
  const currentUser = localStorage.getItem("typeblitz_username");

  // useNavigate lets us go to another page
  const navigate = useNavigate();

  // --- Fetch all players when page loads ---
  useEffect(() => {
    fetchPlayers();
  }, []);

  // Function to fetch players from the backend
  const fetchPlayers = async () => {
    try {
      const response = await fetch(API_URL + "/players");
      const data = await response.json();

      // Separate current user from other players
      // This ensures the current player always appears at the top
      const currentPlayer = data.find((p) => p.username === currentUser);
      const otherPlayers = data.filter((p) => p.username !== currentUser);

      // Put current player first, then all others
      if (currentPlayer) {
        setPlayers([currentPlayer, ...otherPlayers]);
      } else {
        setPlayers(data);
      }

      setLoading(false);
    } catch (error) {
      console.error("Error fetching players:", error);
      setLoading(false);
    }
  };

  // --- Handle logout ---
  const handleLogout = () => {
    // Remove username from localStorage
    localStorage.removeItem("typeblitz_username");
    // Go back to home page
    navigate("/");
  };

  // If no user is logged in, redirect to login
  if (!currentUser) {
    navigate("/login");
    return null;
  }

  return (
    <div className="page-container dashboard-page">
      {/* Page header */}
      <h2 className="page-title">⌨️ TypeBlitz Dashboard</h2>

      {/* Welcome message */}
      <p className="welcome-text">Welcome, <strong>{currentUser}</strong>!</p>

      {/* Player list card */}
      <div className="card">
        <h3>All Players</h3>

        {loading ? (
          <p>Loading players...</p>
        ) : (
          <table className="player-table">
            <thead>
              <tr>
                <th>Player</th>
                <th>Typing Range</th>
              </tr>
            </thead>
            <tbody>
              {players.map((player) => (
                <tr
                  key={player._id}
                  className={player.username === currentUser ? "current-player" : ""}
                >
                  <td>
                    {player.username}
                    {/* Show a star next to current player */}
                    {player.username === currentUser && " ⭐"}
                  </td>
                  <td>{player.typingRange}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Action buttons */}
      <div className="button-group">
        <button className="btn btn-primary" onClick={() => navigate("/practice")}>
          📝 Practice
        </button>
        <button className="btn btn-success" onClick={() => navigate("/test")}>
          🏆 Test
        </button>
      </div>

      {/* Logout button */}
      <button className="btn btn-link" onClick={handleLogout}>
        Logout
      </button>
    </div>
  );
}

export default Dashboard;
