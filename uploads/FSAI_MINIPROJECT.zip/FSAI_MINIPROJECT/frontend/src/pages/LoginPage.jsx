// ============================================
// LoginPage.jsx — Login Page (For Existing Players)
// ============================================
// PURPOSE: Allow existing players to enter the game.
//
// LOGIN VERIFICATION LOGIC:
//   1. Player enters their username.
//   2. Frontend sends username to backend via POST /login.
//   3. Backend checks MongoDB:
//      - If username exists → allow player to enter dashboard.
//      - If username does NOT exist → show error message
//        and suggest the player to sign up.
// ============================================

import { useState } from "react";
import { useNavigate } from "react-router-dom";

// Backend URL (Express server)
const API_URL = "http://localhost:5001";

function LoginPage() {
  // State to store the username typed by the player
  const [username, setUsername] = useState("");

  // State to store any error message
  const [error, setError] = useState("");

  // State to show loading while waiting for server response
  const [loading, setLoading] = useState(false);

  // useNavigate lets us go to another page
  const navigate = useNavigate();

  // --- Handle login button click ---
  const handleLogin = async () => {
    // Clear any previous error
    setError("");

    // Check if username is empty
    if (username.trim() === "") {
      setError("Please enter a username.");
      return;
    }

    // Show loading
    setLoading(true);

    try {
      // Send POST request to /login on the backend
      // This checks if the player already exists in MongoDB
      const response = await fetch(API_URL + "/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: username.trim() }),
      });

      // Parse the JSON response
      const data = await response.json();

      if (!response.ok) {
        // Server returned an error (e.g., player not found)
        setError(data.error);
        setLoading(false);
        return;
      }

      // Login successful — save username in localStorage
      // localStorage keeps data even after page refresh
      localStorage.setItem("typeblitz_username", username.trim());

      // Go to the dashboard page
      navigate("/dashboard");
    } catch (err) {
      // Network error or server not running
      setError("Cannot connect to server. Make sure the backend is running.");
      setLoading(false);
    }
  };

  // --- Handle Enter key press ---
  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleLogin();
    }
  };

  return (
    <div className="page-container login-page">
      {/* Page title */}
      <h2 className="page-title">Login</h2>

      {/* Card container */}
      <div className="card">
        {/* Username input field */}
        <label className="input-label">Enter your username:</label>
        <input
          type="text"
          className="text-input"
          placeholder="e.g. Mary"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          onKeyDown={handleKeyPress}
        />

        {/* Show error message if any */}
        {error && <p className="error-message">{error}</p>}

        {/* Login button */}
        <button
          className="btn btn-primary"
          onClick={handleLogin}
          disabled={loading}
        >
          {loading ? "Logging in..." : "Login"}
        </button>
      </div>

      {/* Link to go to Signup page if no account */}
      <button className="btn btn-link" onClick={() => navigate("/signup")}>
        Don't have an account? Sign Up
      </button>

      {/* Back to home link */}
      <button className="btn btn-link" onClick={() => navigate("/")}>
        ← Back to Home
      </button>
    </div>
  );
}

export default LoginPage;
