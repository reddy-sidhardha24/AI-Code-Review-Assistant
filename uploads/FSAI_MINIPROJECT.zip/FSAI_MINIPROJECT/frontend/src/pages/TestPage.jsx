// ============================================
// TestPage.jsx — Typing Speed Test
// ============================================
// The player takes a typing test:
// 1. A random sentence is shown (from backend)
// 2. A timer starts counting up
// 3. Player types the sentence
// 4. When done, typing speed is calculated
// 5. Speed is converted to a range (0-100%)
// 6. Range is saved to database
// 7. Player is redirected to the Result page
//
// Typing Range Calculation:
//   WPM (Words Per Minute) = (number of characters / 5) / (time in minutes)
//   Range = (WPM / 80) * 100, capped at 100%
//   Example: 40 WPM → 50%, 80+ WPM → 100%
// ============================================

import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";

// Backend URL
const API_URL = "http://localhost:5001";

function TestPage() {
  // The sentence to type
  const [testText, setTestText] = useState("");

  // What the player is typing
  const [userInput, setUserInput] = useState("");

  // Timer state (in seconds)
  const [timer, setTimer] = useState(0);

  // Whether the test has started
  const [started, setStarted] = useState(false);

  // Whether the test is finished
  const [finished, setFinished] = useState(false);

  // Loading state while fetching text
  const [loading, setLoading] = useState(true);

  // Reference to the timer interval (so we can stop it later)
  const timerRef = useRef(null);

  // Navigation
  const navigate = useNavigate();

  // Get current username from localStorage
  const currentUser = localStorage.getItem("typeblitz_username");

  // --- Fetch a random test sentence when page loads ---
  useEffect(() => {
    fetchTestText();

    // Cleanup: stop timer when page is closed
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  // Function to get a random sentence from the backend
  const fetchTestText = async () => {
    try {
      const response = await fetch(API_URL + "/generate-test");
      const data = await response.json();
      setTestText(data.text);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching test text:", error);
      setTestText("The quick brown fox jumps over the lazy dog.");
      setLoading(false);
    }
  };

  // --- Start the timer when the player begins typing ---
  const startTimer = () => {
    if (!started) {
      setStarted(true);
      // Start a timer that increases every second
      timerRef.current = setInterval(() => {
        setTimer((prev) => prev + 1);
      }, 1000);
    }
  };

  // --- Handle input change ---
  const handleInputChange = (e) => {
    // Start timer on first keypress
    startTimer();
    setUserInput(e.target.value);
  };

  // --- Count how many characters the player typed CORRECTLY ---
  // Compare each character of userInput against testText one-by-one
  const countCorrectChars = () => {
    let correctCount = 0;
    // Only compare up to the shorter length
    const maxLen = Math.min(userInput.length, testText.length);
    for (let i = 0; i < maxLen; i++) {
      if (userInput[i] === testText[i]) {
        correctCount++; // character matches — count it
      }
    }
    return correctCount;
  };

  // --- Handle test submission ---
  const handleSubmit = async () => {
    // Stop the timer
    clearInterval(timerRef.current);
    setFinished(true);

    // --- Count only CORRECT characters (not total typed) ---
    const correctChars = countCorrectChars();
    const totalTyped = userInput.length;
    const timeInMinutes = timer / 60;

    // --- Calculate accuracy (what % of typed characters are correct) ---
    let accuracy = 0;
    if (totalTyped > 0) {
      accuracy = Math.round((correctChars / testText.length) * 100);
    }

    // --- Calculate WPM based on CORRECT characters only ---
    // WPM = (correct characters / 5) / (time in minutes)
    // We use correctChars instead of totalTyped so wrong typing doesn't count
    let wpm = 0;
    if (timeInMinutes > 0) {
      wpm = Math.round((correctChars / 5) / timeInMinutes);
    }

    // --- Convert WPM to a range (0–100%) ---
    // 80 WPM = 100% (expert level)
    // Formula: range = (wpm / 80) * 100
    let typingRange = Math.min(100, Math.round((wpm / 80) * 100));

    // Make sure range is not negative
    if (typingRange < 0) typingRange = 0;

    // --- Save the result to the database ---
    try {
      await fetch(API_URL + "/update-range", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: currentUser,
          typingRange: typingRange,
        }),
      });
    } catch (error) {
      console.error("Error saving result:", error);
    }

    // --- Navigate to the result page ---
    // Pass typing range, wpm, accuracy, and time to the result page
    navigate("/result", {
      state: {
        typingRange: typingRange,
        wpm: wpm,
        accuracy: accuracy,
        timeTaken: timer,
      },
    });
  };

  // --- Handle Enter key press ---
  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleSubmit();
    }
  };

  // --- Format timer as MM:SS ---
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // If no user is logged in, redirect to login
  if (!currentUser) {
    navigate("/login");
    return null;
  }

  return (
    <div className="page-container test-page">
      {/* Page title */}
      <h2 className="page-title">🏆 Typing Speed Test</h2>

      <div className="card">
        {loading ? (
          <p>Loading test text...</p>
        ) : (
          <>
            {/* Timer display */}
            <div className="timer-display">
              ⏱️ Time: {formatTime(timer)}
            </div>

            {/* Text to type */}
            <div className="test-text-display">
              <p className="pattern-label">Type this sentence:</p>
              <p className="pattern-text">{testText}</p>
            </div>

            {/* Input area */}
            <textarea
              className="test-input"
              placeholder="Start typing here..."
              value={userInput}
              onChange={handleInputChange}
              onKeyDown={handleKeyPress}
              onPaste={(e) => e.preventDefault()}  // block paste
              onCopy={(e) => e.preventDefault()}   // block copy
              onCut={(e) => e.preventDefault()}    // block cut
              disabled={finished}
              rows={3}
              autoFocus
            />

            {/* Submit button */}
            {!finished && (
              <button className="btn btn-success" onClick={handleSubmit}>
                Submit
              </button>
            )}

            {/* Hint */}
            {!started && (
              <p className="hint-text">Start typing to begin the timer!</p>
            )}
          </>
        )}
      </div>

      {/* Back to dashboard button */}
      <button className="btn btn-link" onClick={() => navigate("/dashboard")}>
        ← Back to Dashboard
      </button>
    </div>
  );
}

export default TestPage;
